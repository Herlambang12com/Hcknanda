# santet-online
Tool receh buat santet orang secara online XD<br/>
Author udh pada gila semua XD hehe

### Requirements
• Python 2.7

#### Installation and Using santet-online
```
git clone https://github.com/Gameye98/santet-online
```
```
cd santet-online
```
```
python santet.py
```

#### Join US
*.[Facebook](https://mobile.facebook.com/groups/1704985559810669)<br/>
*.[Telegram](https://t.me/joinchat/HI69pRAkvhZsCU0Ni9ZIOQ)
